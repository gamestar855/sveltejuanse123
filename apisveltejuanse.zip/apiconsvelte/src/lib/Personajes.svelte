<script>
  import { onMount } from "svelte";

  async function obtenerPersonajes() {
    const respuesta = await fetch(
      "https://dragonball-api.com/api/characters/?limit=58",
    );
    const datos = await respuesta.json();
    return datos.items;
  }

  let personajes = [];

  onMount(async () => {
    personajes = await obtenerPersonajes();
    console.log(personajes);
  });
</script>

<h1 class="ps-10 text-center pt-10 text-4xl font-bold">Personajes</h1>
<section class="p-10 grid grid-cols-6 gap-8">
  {#each personajes as personaje}
    <article class="max-w-sm rounded-lg overflow-hidden shadow-lg border">
      <div class="flex justify-center pt-4">
        <img class="h-60" src={personaje.image} alt="" />
      </div>
      <div class="flex items-center justify-center text-center my-4 px-6">
        <div class="font-bold text-3xl">{personaje.name}</div>
      </div>
      <hr class="mb-4" />
      <div class="flex items-center justify-center px-6 mt-2">
        <span class="text-xl font-bold mr-2 mb-2"
          >Afiliación: {personaje.affiliation}</span
        >
      </div>
      <div class="flex items-center justify-center px-6 mt-2">
        <span
          class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"
          >{personaje.race}</span
        >
        <span
          class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"
          >{personaje.gender}</span
        >
      </div>
      <div class="flex flex-col justify-center items-center px-6">
        <span class="text-xl font-bold">Ki Base:</span>
        <span class="text-2xl font-bold text-yellow-500"> {personaje.ki}</span>
      </div>
      <div class="flex flex-col justify-center items-center px-6 mb-6">
        <span class="text-xl font-bold">Ki Total:</span>
        <span class="text-2xl font-bold text-yellow-500">
          {personaje.maxKi}</span
        >
      </div>
    </article>
  {/each}
</section>
