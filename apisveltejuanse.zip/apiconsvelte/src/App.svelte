<script>
  import Header from './lib/Header.svelte';
  import Personajes from './lib/Personajes.svelte';
</script>
<!-- <HTML> -->
  <Header />
  <main>
      <Personajes />
  </main>
<!-- </HTML> -->
<style>
</style>
