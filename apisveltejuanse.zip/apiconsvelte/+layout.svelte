<script>
    import "./src/app.css";
</script>
  
  <slot />